package chrome;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AuthenticationHandling {
	static WebDriver driver;

	public static void main(String[] args) {
	
				WebDriverManager.chromedriver().setup();
				 driver= new ChromeDriver();
				 
				driver.get("https://admin:admin@the-internet.herokuapp.com/basic_auth");
				driver.manage().window().maximize();
				
				String success=driver.findElement(By.tagName("p")).getText();
				System.out.println(success);


			}

		
	}

